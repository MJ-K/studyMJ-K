package test;
public class test2 {
    public static void main(String[] args) {
        /*test gui = new test();
        gui.init();*/
    }
}

