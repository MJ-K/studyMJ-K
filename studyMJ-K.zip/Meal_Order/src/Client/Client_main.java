package Client;

//import Client_not_use.Client_Main_home;

public class Client_main {
	public static void main(String[] args) {
		//new Client_Main_home();
		new Client_Main_Home_Grid();
	}
}

