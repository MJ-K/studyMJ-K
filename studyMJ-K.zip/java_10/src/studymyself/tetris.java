package studymyself;

public class tetris {
	//테트리스
	public static void main(String[] args) {
		
	}
}
