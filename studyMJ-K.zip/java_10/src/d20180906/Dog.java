package d20180906;

public class Dog extends Animal {

	Dog(String name, String food) {
		super(name, food);
		// TODO Auto-generated constructor stub
	}

}
