package d20180906;

public class 토끼 extends 포유류 {
	
	int 귀;
	
	
	@Override
	public void 먹기() {
		System.out.println("토끼는 배추를 먹어요");

	}

	@Override
	public void 자기() {
		System.out.println("토끼는 숲 속에서 자요");
	}
	
	public void 점프() {
		System.out.println("깡총깡총");
	}

}









