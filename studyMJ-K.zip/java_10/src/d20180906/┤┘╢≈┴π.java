package d20180906;

public class 다람쥐 extends 포유류 {
	int 꼬리;
	
	
	@Override
	public void 먹기() {
		System.out.println("다람쥐는 도토리를 먹어요");
		
	}

	@Override
	public void 자기() {
		System.out.println("다람쥐는 나무 위에서 자요");
		
	}
	
	public void 나무오르기() {
		System.out.println("영차 영차");
	}

}










