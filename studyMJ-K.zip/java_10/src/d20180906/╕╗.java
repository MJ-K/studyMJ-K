package d20180906;

public class 말 extends 포유류 {
	
	
	@Override
	public void 먹기() {
		System.out.println("말은 당근을 먹어요");
		
	}

	@Override
	public void 자기() {
		System.out.println("말은 서서 자요");
		
	}

	public void 달리기() {
		System.out.println("말은 앞만 보고 달려요");
	}
}
