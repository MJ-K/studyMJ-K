package d20180906;

public class Cat extends Animal {

	Cat(String name, String food) {
		super(name, food);
		// TODO Auto-generated constructor stub
	}
	
	

}
