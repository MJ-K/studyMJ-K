package d20180906;

public class Man {
	String name;
	
	Man(String name){
		this.name = name;
	}
	
	void tellName() {
		System.out.println("Name is : "+ name);
	}
	
	
}
