package d20180827;

//식별자
//1. Primitive type
//정수형 : byte, short, int ,long

public class VarEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//변수 : 데이터를 저장하거나 참조하기 위해 메모리 공간을 할당하는 것
		//변수 사용법 : 자료형
		//heap 과 stack
		
		byte b1;
		//초기화
		b1 = 127;// 대입연산자 (=), 같다는 (==)
		
		short sh = 32767;		
		
		int it;
		it= 928457;
		
		long lo = 45646544;
		
		
	}

}
