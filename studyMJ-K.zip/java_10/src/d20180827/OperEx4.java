package d20180827;
//4. 비교연산자
public class OperEx4 {
	public static void main(String[] args) {
		 
		int a = 20;
		int b = 10;
		 
		System.out.println(" a > b : "+ (a>b)); 
		System.out.println(" a < b : "+ (a<b)); 
		System.out.println(" a >= b : "+ (a>=b)); 
		System.out.println(" a <= b : "+ (a<=b)); 
		System.out.println(" a == b : "+ (a==b)); 
		System.out.println(" a != b : "+ (a!=b)); 
		
	}
}
