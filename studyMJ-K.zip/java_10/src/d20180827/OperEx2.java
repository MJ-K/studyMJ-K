package d20180827;

//2. 산술연산자 : +, -, *, /, %
public class OperEx2 {
	public static void main(String[] args) {
		
		int a = 100;
		int b = 200;
		
		System.out.println(" a + b = "+a + b);//연결연산자
		System.out.println(" a + b = "+(a + b));//산술연산자
		System.out.println(" a - b = "+(a - b));//산술연산자
		System.out.println(" a * b = "+(a * b));//산술연산자
		System.out.println(" a / b = "+(a / b));//산술연산자
		System.out.println(" a % b = "+(a % b));//산술연산자
		
	}
}
