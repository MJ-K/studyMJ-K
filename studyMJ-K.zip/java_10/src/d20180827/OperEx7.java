package d20180827;
//7.삼항연산자
public class OperEx7 {
	public static void main(String[] args) {
		
		int a = 10;
		int b = 5;
		
		//(조건)? 참 : 거짓
		
		System.out.println((a>b)? "참" : "거짓");
		System.out.println((a<b)? "참" : "거짓");
	
	}
}
