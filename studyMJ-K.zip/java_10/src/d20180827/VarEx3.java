package d20180827;

public class VarEx3 {
	public static void main(String args[]) {
		 
		float f1 = 3.14152f;
		
		double d1 = 3.14343;
		
		System.out.println("f1 : " + f1);
		System.out.println("d1 : " + d1);
	}
}
