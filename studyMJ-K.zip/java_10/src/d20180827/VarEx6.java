package d20180827;
//논리형 : boolean
public class VarEx6 {
	public static void main(String[] args) {
			
		//0,1 (c언어)
		//true,false
		
		boolean b11 = true;
		boolean b12 = false;
		
		System.out.println("b11 :" +b11);
		System.out.println("b12 :" +b12);
		System.out.println("--------------------");
		System.out.println(2 < 1);
	}
}
