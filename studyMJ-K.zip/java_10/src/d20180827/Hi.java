package d20180827;


public class Hi {
	public static void main(String args[]) {
		System.out.println("처음 만든 프로그램");
	}
}
