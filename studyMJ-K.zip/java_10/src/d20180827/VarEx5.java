package d20180827;

public class VarEx5 {
	public static void main(String[] args) {
		char ch5 = 'A'; // 문자형
		char ch6 = 65; // ASCII코드
		char ch7 = '\u0063'; //unicode 입력
		char ch8= 99;
		
		System.out.println("ch5 : "+ch5);
		System.out.println("ch6 : "+ch6);
		System.out.println("ch7 : "+ch7);
		System.out.println("ch8 : "+ch8);
		
		System.out.println("-----------------------------");
		System.out.println("오늘은\n월요일입니다.\t 내일은 화요일입니다.");
	}
}
