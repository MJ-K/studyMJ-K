package d20180828;

public class SwitchBasic {
	 public static void main(String[] args) {
		
		 int num = 3;
		 
		 switch(num) { 
		 case 1 : 
			 System.out.println("Switch case 1 : Hello Java");
			 break;
		 case 2 :
			 System.out.println("Switch case 2 : Wow Java");
			 break;
		 case 3 :
			 System.out.println("Switch case 3 : Fantasy Java");
			 break;
		 default :
			 System.out.println("Switch default : Simple Java");
		 }
		 
	}
}
