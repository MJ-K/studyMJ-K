package exam_02;

public class HwNo4 {
	public static void main(String[] args) {
		
		/*4. 구구단 3단을 옆으로 출력하기
		예)
		3 * 1 = 3   3 * 2 = 6   3 * 3 = 9 ...   3 * 9 = 27*/

		
		//println 말고 print사용, "\t" 이용.(선택)
		
		for(int i=1;i<10;i++) {
			
			System.out.print("3 * "+i+" = "+(3*i)+"\t");
			
		}
	}
}
