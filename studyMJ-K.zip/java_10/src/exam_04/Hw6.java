package exam_04;

public class Hw6 {
	public static void main(String[] args) {
		int a = 20;
        int[] b = {10,20,50,30};
        float f = 240.3f;

        FormatData fd = new FormatData();

        fd.print(a);
        fd.print(b);
        fd.print(f);
	}
}
