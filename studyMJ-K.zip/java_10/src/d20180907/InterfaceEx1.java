package d20180907;

public interface InterfaceEx1 {
	// 인터페이스에는 추상메소드와 상수만이 존재
	// 인터페이스 객체는 추상객체이므로 abstract 생략 가능
	
	public int NUM = 100;
	public void calculate();
}
