package d20180907;

public interface InterfaceEx2 {
	public String STR = "Hello Java";
	public String getStr();
}
