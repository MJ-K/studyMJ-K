package problem02;

public interface Arithmetic {
	int calculate( int a, int b );
}